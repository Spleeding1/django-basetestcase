name = 'basetestcase'

__version__ = '1.0.3'

from .base_FormTestCase import *
from .base_FunctionalTestCase import *
from .base_ModelTestCase import *
from .base_ViewTestCase import *